//
//  PAC1TFGApp.swift
//  PAC1TFG
//
//  Created by Eric Cabestany Mena on 21/2/22.
//

import SwiftUI

@main
struct PAC1TFGApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
