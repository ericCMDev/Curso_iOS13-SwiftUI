//
//  ContentView.swift
//  PAC1TFG
//
//  Created by Eric Cabestany Mena on 21/2/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("PAC1!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
